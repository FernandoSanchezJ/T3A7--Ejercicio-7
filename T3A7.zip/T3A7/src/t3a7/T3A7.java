package t3a7;

import java.util.Scanner;

public class T3A7 {

    public static void main(String[] args) {
        //ejer1();
        //ejer2();
        ejer4();
    }

    public static void ejer1() {
        Scanner sc = new Scanner(System.in);

        System.out.println("cuantos numeros quieres sumar:");
        int limite = sc.nextInt();

        System.out.println("ingresa el numero de inicio:");
        int inicio = sc.nextInt();

        System.out.println("ingresa el numero de incremento:");
        int incremento = sc.nextInt();
         
        int ns = inicio + limite;

        for (int i = inicio; i < ns; i = i + incremento) {

            System.out.println("suma se los numeros " + i);
        }
    }
    public static void ejer2(){
        Scanner sc1 = new Scanner(System.in);
        int n = 1;
        
        System.out.println("primer numero impar");
        int n1 = sc1.nextInt();
        if( n1 == 2*n1 +1 || n1 == n){
            System.out.println(n1);
        }else{
            System.out.println("no es un numero impar");
        }
        System.out.println("segundo numero impar");
        int n2 = sc1.nextInt();
        if( n2 == 2*n2+1 || n2 == n){
            System.out.println(n1);
        }else{
            System.out.println("no es un numero impar");
        }
        
        System.out.println("tercer numero impar");
        int n3 = sc1.nextInt();
        if( n3 == 2*n3+1 || n3 == n){
            System.out.println(n1);
        }else{
            System.out.println("no es un numero impar");
        }
        
        System.out.println("cuarto numero impar");
        int n4 = sc1.nextInt();
        if( n4 == 2*n4+1 || n4 == n){
            System.out.println(n1);
        }else{
            System.out.println("no es un numero impar");
        }
        System.out.println("quinto numero impar");
        int n5 = sc1.nextInt();
        if( n5 == 2*n5+1 || n5 == n){
        }else{
            System.out.println("no es un numero impar");
        }
        System.out.println("sexto numero impar");
        int n6 = sc1.nextInt();
        if( n6 == 2*n6+1 || n6 == n){
        }else{
            System.out.println("no es un numero impar");
        }
        System.out.println("septimo numero impar");
        int n7 = sc1.nextInt();
        if( n7 == 2*n7+1 || n7 == n){
        }else{
            System.out.println("no es un numero impar");
        }
        System.out.println("octavo numero impar");
        int n8 = sc1.nextInt();
        if( n8 == 2*n8+1 || n8 == n){
        }else{
            System.out.println("no es un numero impar");
        }
        System.out.println("noveno numero impar");
        int n9 = sc1.nextInt();
        if( n9 == 2*n9+1 || n9 == n){
        }else{
            System.out.println("no es un numero impar");
        }
        System.out.println("decimo numero impar");
        int n10 = sc1.nextInt();
        if( n10 == 2*n10+1 || n10 == n){
        }else{
            System.out.println("no es un numero impar");
        }
        int producto = (n1*n2*n3*n4*n5*n6*n7*n8*n9*n10);
        System.out.println("el producto de los 10 numeros es:" + producto);
    }
    public static void ejer3(){
        
    }
    
    /*Dadas las edades y alturas de 5 alumnos, mostrar la edad y la 
    estatura media, la cantidad de alumnos mayores de 18 años, y la 
    cantidad de alumnos que miden más de 1.75.*/

    public static void ejer4(){
        Scanner sc4 = new Scanner(System.in);
        int edad;
        float estatura;       
        int mayor = 0;
        int mayorEdad = 0;
        
        for(int i = 0; i< 5; i++){
            System.out.println("edad:");
            edad = sc4.nextInt();  
            if(edad >= 18){
                mayorEdad++;
            }
            System.out.println("Estatura:");
            estatura = sc4.nextFloat();
            if(estatura > 175){
                mayor++;
            }
            /*float suma = (estatura + estatura);
            double promedioEstatura = (suma/5);
            */
/*            System.out.println("mayor de 18 años: "+ mayorEdad);
            System.out.println("estatura mayor de 175: " + mayor);*/

        }
        System.out.println("mayores de 175 de estatura" + mayor);
        System.out.println("promedio de edad" + mayorEdad);
    }
}
